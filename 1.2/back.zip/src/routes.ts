import { Router } from 'express';

import { UserController } from './controller/UserController';
import { AuthController } from './controller/AuthController';
import { AuthMiddlewares } from './middleware/auth';
import { InstitutionController } from './controller/InstitutionController';

const usercontroller = new UserController();
const authcontroller = new AuthController();
const institutionController = new InstitutionController();

export const router = Router();

router.post("/create",usercontroller.store)
router.get("/users", usercontroller.index)
router.post("/auth", authcontroller.authenticate)
router.delete("/delete", AuthMiddlewares, usercontroller.deleteAccount);
router.patch("/update", AuthMiddlewares, usercontroller.update);
router.post("/institution", AuthMiddlewares,institutionController.store);
router.get("/institutions",AuthMiddlewares, institutionController.index);
router.get("/institution/listall", institutionController.listAll);
router.get("/institution/:id", institutionController.show);
router.get('/users/:id', usercontroller.show);