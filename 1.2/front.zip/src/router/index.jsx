
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Login } from '../pages/login'
import { Register } from '../pages/register'
import { Home } from '../pages/home'
import { PrivateRoutes } from './privateRoutes'
import { InstitutionRegister } from '../pages/institution'
import { InfoUser } from '../pages/infoUser'
import { InfoInstitution } from '../pages/infoinstitution'
import { UserInfoPage } from '../pages/perfilUser'


export const AppRouter = () => {
    return(
        <Router>
            <Routes>
                 <Route path='/' exact element={ <Home/> } /> 
                 <Route path='/login' exact element={ <Login/> } /> 
                 <Route path='/register' exact element={ <Register/> } /> 
                 <Route path="/institution-create" exact element={ <InstitutionRegister /> } />
                 <Route path="/infoinstitution" exact element={ <InfoInstitution /> } />
                 <Route path="/userinfo" exact element={ <UserInfoPage /> } />
                 <Route path='/infouser' element={<PrivateRoutes/>} >
                    <Route path='/infouser' exact element={ <InfoUser/> } /> 
                 </Route>      
            </Routes>
        </Router>
    )
}