import { AppRouter } from "./router";
import "./assets/global.css";
import { AuthProvider } from "./context/auth";
import { InstitutionProvider } from "./context/institutionContext"


export const App = () => {
  return (
    <AuthProvider>
      <InstitutionProvider>
        <AppRouter />
      </InstitutionProvider>

    </AuthProvider>

  )
}
