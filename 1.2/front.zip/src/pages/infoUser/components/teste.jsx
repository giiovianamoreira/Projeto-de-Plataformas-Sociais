
export const Component2= () =>
    {
        return <div>Conteúdo do Item 2</div>;
    }