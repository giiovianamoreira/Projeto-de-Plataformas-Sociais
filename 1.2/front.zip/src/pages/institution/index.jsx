// src/pages/InstitutionRegister.jsx

import React, { useState, useEffect } from 'react';
import { useInstitution } from '../../context/institutionContext';
import { BasicInfos } from './components/BasicInfo';
import { EnderecoInsti } from './components/Address';

export const InstitutionRegister = () => {
  const [nome, setNome] = useState('');
  const [cnpj, setCnpj] = useState('');
  // Adicione outros estados conforme necessário
  const [endereco, setEndereco] = useState('');
  const [rua, setRua] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');
  const [cep, setCep] = useState('');
  const [telefone, setTelefone] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [facebook, setFacebook] = useState('');
  const [instagram, setInstagram] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [descricao, setDescricao] = useState('');
  const [areasAtuacao, setAreasAtuacao] = useState('');
  const [publicoAlvo, setPublicoAlvo] = useState('');
  const [projetos, setProjetos] = useState('');
  const [nomeResponsavel, setNomeResponsavel] = useState('');
  const [horarioFuncionamento, setHorarioFuncionamento] = useState('');
  const { registerInstitution, fetchInstitutions, institutions } = useInstitution();

  useEffect(() => {
    fetchInstitutions(); // Carrega as instituições ao montar o componente
  }, [fetchInstitutions]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const institutionData = {
      nome,
      cnpj,
      endereco,
      rua,
      numero,
      complemento,
      bairro,
      cidade,
      estado,
      cep,
      telefone,
      email,
      website,
      facebook,
      instagram,
      linkedin,
      descricao,
      areasAtuacao,
      publicoAlvo,
      projetos,
      nomeResponsavel,
      horarioFuncionamento,
    };

    registerInstitution(institutionData);
    // Limpa os campos após o envio
    setNome('');
    setCnpj('');
    setEndereco('');
    setRua('');
    setNumero('');
    setComplemento('');
    setBairro('');
    setCidade('');
    setEstado('');
    setCep('');
    setTelefone('');
    setEmail('');
    setWebsite('');
    setFacebook('');
    setInstagram('');
    setLinkedin('');
    setDescricao('');
    setAreasAtuacao('');
    setPublicoAlvo('');
    setProjetos('');
    setNomeResponsavel('');
    setHorarioFuncionamento('');
  };

  return (
    <div>
      <h1>Cadastro de Instituição</h1>
      <form onSubmit={handleSubmit}>
        <BasicInfos 
          nome={nome}
          setNome={setNome}
          cnpj={cnpj}
          setCnpj={setCnpj}
        />
        <EnderecoInsti
          rua={rua}
          setRua={setRua}
          numero={numero}
          setNumero={setNumero}
          complemento={complemento}
          setComplemento={setComplemento}
          bairro={bairro}
          setBairro={setBairro}
          cidade={cidade}
          setCidade={setCidade}
          estado={estado}
          setEstado={setEstado}
          cep={cep}
          setCep={setCep}
        />
        {/* Adicione outros componentes conforme necessário */}
        <div>
          <label>Endereço</label>
          <input 
            type="text" 
            value={endereco} 
            onChange={(e) => setEndereco(e.target.value)} 
            required 
          />
        </div>
        {/* Continue com os outros campos conforme necessário */}
        <button type="submit">Cadastrar</button>
      </form>

      <h2>Instituições Cadastradas</h2>
      <ul>
        {institutions.map((inst) => (
          <li key={inst.id}>
            <strong>Nome:</strong> {inst.nome} <br />
            <strong>CNPJ:</strong> {inst.cnpj} <br />
            <strong>Endereço:</strong> {inst.endereco}, <br />
            <strong>Rua:</strong> {inst.rua}, <br />
            <strong>Numero:</strong> {inst.numero}, <br />
            <strong>Complemento:</strong> {inst.complemento}, <br />
            <strong>Bairro:</strong> {inst.bairro}, <br />
            <strong>estado:</strong> {inst.estado}, <br />
            <strong>Cep:</strong> {inst.cep}, <br />
            <strong>Telefone:</strong> {inst.telefone} 
            <strong>E-mail:</strong> {inst.email} <br />
            <strong>Website:</strong> {inst.website} <br />
            <strong>Facebook:</strong> {inst.facebook} <br />
            <strong>Instagram:</strong> {inst.instagram} <br />
            <strong>LinkedIn:</strong> {inst.linkedin} <br />
            <strong>Descrição:</strong> {inst.descricao} <br />
            <strong>Áreas de Atuação:</strong> {inst.areasAtuacao} <br />
            <strong>Público Alvo:</strong> {inst.publicoAlvo} <br />
            <strong>Projetos e Programas:</strong> {inst.projetos} <br />
            <strong>Nome do Responsável:</strong> {inst.nomeResponsavel} <br />
            <strong>Horário de Funcionamento:</strong> {inst.horarioFuncionamento}
          </li>
        ))}
      </ul>
    </div>
  );
};
