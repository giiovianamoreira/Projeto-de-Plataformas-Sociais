// src/pages/InstitutionList.jsx

import React, { useEffect, useState } from 'react';
import { useInstitution } from '../../context/institutionContext';
import { InstitutionCard } from './components/card';
import { Link } from 'react-router-dom';

const estadosBrasileiros = [
  "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", 
  "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO"
];

export const Home = () => {
  const { institutions, fetchAllInstitutions } = useInstitution();
  const [filteredInstitutions, setFilteredInstitutions] = useState([]);
  const [selectedState, setSelectedState] = useState("");

  useEffect(() => {
    fetchAllInstitutions();
  }, [fetchAllInstitutions]);

  useEffect(() => {
    if (selectedState === "") {
      setFilteredInstitutions(institutions);
    } else {
      setFilteredInstitutions(
        institutions.filter((inst) => inst.estado === selectedState)
      );
    }
  }, [institutions, selectedState]);

  const handleStateChange = (e) => {
    setSelectedState(e.target.value);
  };

  return (
    <div>
      <Link to="/login">login</Link>
      <h1>Lista de Instituições</h1>

      <div>
        <label>Filtrar por Estado: </label>
        <select id="stateFilter" value={selectedState} onChange={handleStateChange}>
          <option value="">Todos os Estados</option>
          {estadosBrasileiros.map((estado) => (
            <option key={estado} value={estado}>
              {estado}
            </option>
          ))}
        </select>
      </div>

      <div className="institution-cards">
        {filteredInstitutions.length > 0 ? (
          filteredInstitutions.map((inst) => (
            <InstitutionCard key={inst.id} institution={inst} />
          ))
        ) : (
          <p>Nenhuma instituição encontrada para o estado selecionado.</p>
        )}
      </div>
    </div>
  );
};
