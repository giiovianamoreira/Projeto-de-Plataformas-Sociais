import  { useEffect, useState } from 'react';
import { api } from '../../services/api';

export const InfoInstitution = () => {
  const [institution, setInstitution] = useState(null);

  useEffect(() => {
   
    const institutionId = localStorage.getItem('institutionId');

    const fetchInstitution = async () => {
      try {
        const response = await api.get(`/institution/${institutionId}`);
        setInstitution(response.data);
      } catch (error) {
        console.error('Erro ao buscar a instituição:', error);
      }
    };

    fetchInstitution();
  }, []);

  if (!institution) {
    return <p>Carregando informações da instituição...</p>;
  }
  const handleOpenUserPage = () => {
    // Armazenar o ID do usuário no localStorage
    localStorage.setItem('userId', institution.userId);

    // Abrir a nova aba com as informações do usuário
    window.open('/userInfo', '_blank');
  }; 
  return (
    <div>
      <h1>{institution.nome}</h1>
      <p><strong>CNPJ:</strong> {institution.cnpj}</p>
      <p><strong>Endereço:</strong> {institution.endereco}, {institution.rua}, {institution.numero}, {institution.complemento}, {institution.bairro}, {institution.cidade}, {institution.estado}, {institution.cep}</p>
      <p><strong>Telefone:</strong> {institution.telefone}</p>
      <p><strong>E-mail:</strong> {institution.email}</p>
      <p><strong>Website:</strong> {institution.website}</p>
      <p><strong>Facebook:</strong> {institution.facebook}</p>
      <p><strong>Instagram:</strong> {institution.instagram}</p>
      <p><strong>LinkedIn:</strong> {institution.linkedin}</p>
      <p><strong>Descrição:</strong> {institution.descricao}</p>
      <p><strong>Áreas de Atuação:</strong> {institution.areasAtuacao}</p>
      <p><strong>Público Alvo:</strong> {institution.publicoAlvo}</p>
      <p><strong>Projetos:</strong> {institution.projetos}</p>
      <p><strong>Nome do Responsável:</strong> {institution.nomeResponsavel}</p>
      <p><strong>Horário de Funcionamento:</strong> {institution.horarioFuncionamento}</p>
      <div className="">
      <p><strong>nome de quem cadastrou a instituição</strong> {institution.user.name}</p>
      <p><strong>email do usuário que cadastrou</strong> {institution.user.email}</p> 
      <button onClick={handleOpenUserPage} className="btn btn-primary">Ver informações do usuário</button>
      </div>
      
    </div>
  );
};
