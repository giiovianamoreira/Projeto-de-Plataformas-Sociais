-- AlterTable
ALTER TABLE "Institution" ADD COLUMN "latitude" REAL;
ALTER TABLE "Institution" ADD COLUMN "longitude" REAL;
