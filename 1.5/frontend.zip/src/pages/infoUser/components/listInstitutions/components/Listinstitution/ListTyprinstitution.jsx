

export const ListtypeInstitution = () => {

    return(
        <div className="list-type-institution">
            <div className="type-institution">
                <p>Aprovadas</p>
                <div className="container-institution">

                </div>
            </div>
        </div>
    )

}